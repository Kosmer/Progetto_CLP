package ast;

public class IntType extends Type{
	public String toPrint(String s) {
		return s + "Int " ;  
	  }

}
